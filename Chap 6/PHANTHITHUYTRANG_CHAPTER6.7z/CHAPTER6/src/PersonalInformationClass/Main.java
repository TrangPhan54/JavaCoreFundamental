package PersonalInformationClass;



public class Main {
    public static void main(String[] args) {
        PersonalInformationClass myInfor = new PersonalInformationClass("Thuy Trang", "HCM city", 24, "123456");
        System.out.println(myInfor);
        PersonalInformationClass myFriendInfor = new PersonalInformationClass("Anna", "New York city", 24, "859474");
        System.out.println(myFriendInfor);
        PersonalInformationClass myMomInfor = new PersonalInformationClass("Hong", "Da Nang city", 56, "86473742");
        System.out.println(myMomInfor);






    }
}
