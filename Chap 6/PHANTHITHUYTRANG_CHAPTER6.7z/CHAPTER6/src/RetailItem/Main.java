package RetailItem;

public class Main {
    public static void main(String[] args) {
        RetailItem itemOne = new RetailItem("Jacket",12,59.95);
        System.out.println(itemOne);
        RetailItem itemTwo = new RetailItem("Designer Jeans",40,34.95);
        System.out.println(itemTwo);
        RetailItem itemThree = new RetailItem("Shirt",20,24.95);
        System.out.println(itemThree);

    }
}
