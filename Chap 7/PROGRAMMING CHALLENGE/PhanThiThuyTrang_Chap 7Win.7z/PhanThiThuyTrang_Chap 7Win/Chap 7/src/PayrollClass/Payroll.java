package PayrollClass;

import java.util.Scanner;

public class Payroll {
    private int[] employeeId = {5658845, 4520125, 7895122, 8777541, 8451277, 1302850, 7580489};
    private int[] hours = new int[7];
    private double[] payRate = new double[7];
    private double[] wages = new double[7];

    public void setEmployeeId(int[] employeeId) {
        this.employeeId = employeeId;
    }
    public int[] getHours() {
        return hours;
    }

    public void setHours(int[] hours) {
        this.hours = hours;
    }
    public double[] getPayRate() {
        return payRate;
    }

    public void setPayRate(double[] payRate) {
        this.payRate = payRate;
    }

    public double[] getWages() {
        return wages;
    }

    public void setWages(double[] wages) {
        this.wages = wages;
    }

    public double getGrossPay (int idNum){
        int index = findEmployee(idNum);

        if (index != -1){
            return this.payRate[index]*this.hours[index];
        } else {
            return 0;
        }
    }

    public int findEmployee (int idNum){
        int index = -1;
        for (int i = 0; i < this.employeeId.length; i++) {
            if(this.employeeId[i]==idNum) {
                index = i;
            }
        }
        return index;
    }



}


