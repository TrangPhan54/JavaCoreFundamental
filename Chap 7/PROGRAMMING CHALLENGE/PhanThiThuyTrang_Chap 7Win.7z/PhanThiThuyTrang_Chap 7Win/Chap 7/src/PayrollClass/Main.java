package PayrollClass;
import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        int[] employeeID = {5658845, 4520125, 7895122,
                8477541, 8451277, 1302850,
                7580489};
        int [] hour = new int[7];
        double [] payRate = new double [7];

        Payroll payroll = new Payroll();
        Scanner sc = new Scanner (System.in);
        for (int i = 0; i<7;i++){
            do {
                System.out.println("enter the working hour of employee " + employeeID[i]);
                hour[i] = sc.nextInt();
                if(hour[i]<0){
                    System.out.println("hour must be greater than 0");
                }
            } while (hour[i]<0);
            do {
                System.out.println("enter the payrate of employee " + employeeID[i]);
                payRate[i] = sc.nextDouble();
                if(payRate[i]<6){
                    System.out.println("payRate must be greater than 6");
                }
            }
            while (payRate[i]<6);

        }
        payroll.setHours(hour);
        payroll.setPayRate(payRate);
        System.out.println("enter employee Id");
        int idNum = sc.nextInt();
        payroll.findEmployee(idNum);
        System.out.println("employee can earn $ "+ payroll.getGrossPay(idNum));


    }
}
