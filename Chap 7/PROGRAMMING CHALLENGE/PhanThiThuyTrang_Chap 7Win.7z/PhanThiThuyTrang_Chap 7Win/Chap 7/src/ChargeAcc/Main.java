package ChargeAcc;

public class Main {
    public static void main(String[] args) {
        int [] numberArray = {5658845,4520125,7895122,8777541,8451277,1302850,8080152,1250255,1005231,4581002,4562555,5552012,5050552,7825877,6545231,3852085,7576651,7881200};
        int results;

        results = sequentialSearch(numberArray, 5658845);

        if (results == -1)
        {
            System.out.println("cannot find the number " +
                    "in the array.");
        }
        else
        {
            System.out.println("can find the number " +
                    "in the array " + (results + 1));
        }
    }
    public static int sequentialSearch(int[] array,
                                       int value)
    {
        int index;
        int element;
        boolean found;

        index = 0;

        element = -1;
        found = false;

        while (!found && index < array.length)
        {
            if (array[index] == value)
            {
                found = true;
                element = index;
            }
            index++;
        }

        return element;
    }

}





