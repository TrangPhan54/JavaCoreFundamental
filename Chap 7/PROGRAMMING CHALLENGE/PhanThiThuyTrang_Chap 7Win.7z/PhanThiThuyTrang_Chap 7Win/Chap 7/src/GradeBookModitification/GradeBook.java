package GradeBookModitification;
import java.text.DecimalFormat;
import java.util.Arrays;

public class GradeBook {
    private String[] name = {"Anna", "Bella", "Sebastian", "Oliver", "Trang"};
    private String[] grade = {"A", "B", "C", "D", "F"};

    private double[] averageScoreList;
    private double[] scoreOne;
    private double[] scoreTwo;
    private double[] scoreThree;
    private double[] scoreFour;
    private double[] scoreFive;

    public GradeBook(double[] scoreOne, double[] scoreTwo, double[] scoreThree, double[] scoreFour, double[] scoreFive) {
        this.scoreOne = scoreOne;
        this.scoreTwo = scoreTwo;
        this.scoreThree = scoreThree;
        this.scoreFour = scoreFour;
        this.scoreFive = scoreFive;
    }


    public void setAverageScoreList() {
        averageScoreList = new double[5];
        averageScoreList[0] = getAverScoreOne();
        averageScoreList[1] = getAverScoreTwo();
        averageScoreList[2] = getAverScoreThree();
        averageScoreList[3] = getAverScoreFour();
        averageScoreList[4] = getAverScoreFive();
    }

//    public void dropTheLowestScore(){
//        DecimalFormat df = new DecimalFormat("#,###.00");
//        for (int i =0; i<5;i++){
//            System.out.println("Student # "+(i+1));
//            System.out.println("\t\t name "+name[i]);
//            System.out.println();
//            double total = 0;
//            double lowest = grade[i];
//





    public double[] getAverageScoreList() {
        return averageScoreList;
    }

    public GradeBook(String[] name) {
        this.name = name;
    }

    public String[] getName() {
        return name;
    }

    public void setName(String[] name) {
        this.name = name;
    }

    public double[] getScoreOne() {
        return scoreOne;
    }

    public void setScoreOne(double[] scoreOne) {
        this.scoreOne = scoreOne;
    }

    public double[] getScoreTwo() {
        return scoreTwo;
    }

    public void setScoreTwo(double[] scoreTwo) {
        this.scoreTwo = scoreTwo;
    }

    public double[] getScoreThree() {
        return scoreThree;
    }

    public void setScoreThree(double[] scoreThree) {
        this.scoreThree = scoreThree;
    }

    public double[] getScoreFour() {
        return scoreFour;
    }

    public void setScoreFour(double[] scoreFour) {
        this.scoreFour = scoreFour;
    }

    public double[] getScoreFive() {
        return scoreFive;
    }

    public void setScoreFive(double[] scoreFive) {
        this.scoreFive = scoreFive;
    }


    public double getAverScoreOne() {
        double total = 0;
        for (int index = 0; index < scoreOne.length; index++) {
            total += scoreOne[index];
        }
        double averageOne = total / scoreOne.length;
        return averageOne;

    }

    public double getAverScoreTwo() {
        double total = 0;
        for (int index = 0; index < scoreTwo.length; index++) {
            total += scoreTwo[index];
        }
        double averageTwo = total / scoreTwo.length;
        return averageTwo;

    }

    public double getAverScoreThree() {
        double total = 0;
        for (int index = 0; index < scoreThree.length; index++) {
            total += scoreThree[index];
        }
        double averageThree = total / scoreThree.length;
        return averageThree;

    }

    public double getAverScoreFour() {
        double total = 0;
        for (int index = 0; index < scoreFour.length; index++) {
            total += scoreFour[index];
        }
        double averageFour = total / scoreFour.length;
        return averageFour;

    }

    public double getAverScoreFive() {
        double total = 0;
        for (int index = 0; index < scoreFive.length; index++) {
            total += scoreFive[index];
        }
        double averageFive = total / scoreFive.length;
        return averageFive;

    }

    public void getGrade(double average) {
        String grade;

        if (average >= 90 && average <= 100) {
            grade = "A";
            System.out.println(grade);
        } else if (average >= 80 && average <= 89) {
            grade = "B";
            System.out.println(grade);
        } else if (average >= 70 && average <= 79) {
            grade = "C";
            System.out.println(grade);
        } else if (average >= 60 && average <= 69) {
            grade = "D";
            System.out.println(grade);
        } else if (average <= 59) {
            grade = "F";
            System.out.println(grade);
        }


    }
}



