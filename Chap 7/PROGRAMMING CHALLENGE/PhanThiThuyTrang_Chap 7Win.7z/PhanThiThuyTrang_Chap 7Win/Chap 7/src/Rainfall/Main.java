package Rainfall;

public class Main {
    public static void main(String[] args) {
        final int MONTHS = 12;
        double[] rainArray = new double[MONTHS];
        Rainfall rainfallArray = new Rainfall(rainArray);

        double result = rainfallArray.getTotal();
        double lowest =  rainfallArray.getLowestRainFall();
        double highest = rainfallArray.getHighestRainFall();

        System.out.println("The total fall rain is " +result);
        System.out.println("The lowest rainfall is "+lowest);
        System.out.println("The highest rainfall is "+highest);


    }}



