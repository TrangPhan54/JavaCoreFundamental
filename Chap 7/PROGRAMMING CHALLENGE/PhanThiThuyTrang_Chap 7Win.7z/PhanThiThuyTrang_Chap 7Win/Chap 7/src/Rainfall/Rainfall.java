package Rainfall;
import java.util.Scanner;
public class Rainfall {
    final int MONTHS = 12;
    private double[] fallingRainArray;

    public Rainfall(double[] fallingRainArray) {
        this.fallingRainArray = fallingRainArray;
    }

    public double getTotal() {
        double total = 0;
        Scanner sc = new Scanner(System.in);
        for (int index = 0; index < MONTHS; index++) {
            System.out.println("rainfall month " + (index + 1) + ":");
            fallingRainArray[index] = sc.nextDouble();
            total += fallingRainArray[index];
        }
        return total;
    }



    public double getLowestRainFall() {
        double lowest = fallingRainArray[0];
        for (int index = 1; index < fallingRainArray.length; index++) {
            if (fallingRainArray[index] < lowest) {
                lowest = fallingRainArray[index];
            }
        }
        return lowest;
    }

    public double getHighestRainFall() {
        double highest = fallingRainArray[0];
        for (int index = 1; index < fallingRainArray.length; index++) {
            if (fallingRainArray[index] > highest) {
                highest = fallingRainArray[index];
            }

        }
        return highest;


    }
}
