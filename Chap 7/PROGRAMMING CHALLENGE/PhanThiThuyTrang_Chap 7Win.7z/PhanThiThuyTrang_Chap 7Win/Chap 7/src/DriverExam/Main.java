package DriverExam;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        String[] stuAns = new String[20];
        Scanner sc = new Scanner(System.in);
        for (int i = 0; i < 20; i++) {
            System.out.println("enter answer of student");
            stuAns[i] = sc.nextLine();
        }
        DriverLicenseExam driver = new DriverLicenseExam(stuAns);

        System.out.println("number of correct answer is "+driver.totalCorrect());
        System.out.println("number of incorrect answer is "+ driver.totalIncorrect());

//        driver.getCorrectAnswer();
    }
}
