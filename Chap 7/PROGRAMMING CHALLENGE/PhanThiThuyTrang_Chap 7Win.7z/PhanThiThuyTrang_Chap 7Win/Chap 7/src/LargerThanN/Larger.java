package LargerThanN;
import java.util.Scanner;
public class Larger {
    final int LONG = 5;

    private int [] specialArray;

    public Larger(int[] specialArray) {
        this.specialArray = specialArray;
    }

    public Larger(int[] firstArray, int number) {
        this.specialArray = firstArray;

//        for (int index = 0; index< LONG; index++){
//            if (specialArray[index]>number) {
//                System.out.println(specialArray[index]);
//            }

    }

    public void compareNumber (int number) {
        for (int index = 0; index< LONG; index++){
            if (specialArray[index]>number) {
                System.out.println(specialArray[index]);
            }
        }
    }
}
