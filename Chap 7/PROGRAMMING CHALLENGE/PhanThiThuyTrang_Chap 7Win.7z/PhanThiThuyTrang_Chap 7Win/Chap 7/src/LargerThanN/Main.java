package LargerThanN;

import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        final int LONG  = 5;
        int [] firstArray = new int [LONG] ;
        Scanner kb = new Scanner(System.in);
        for(int i =0; i< firstArray.length; i++) {
            System.out.println("Enter value " + (i+1) +": ");
            firstArray[i] = kb.nextInt();
        }
        Larger largerNumber = new Larger (firstArray);
        System.out.println("Enter a value to compare");
        int value = kb.nextInt();
        largerNumber.compareNumber(value);

    }
}
