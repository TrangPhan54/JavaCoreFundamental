package AverGrade;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        double[] scoreStu1 = new double[4];
        double[] scoreStu2 = new double[4];
        double[] scoreStu3 = new double[4];
        double[] scoreStu4 = new double[4];
        double[] scoreStu5 = new double[4];
        GradeBook scoreStu = new GradeBook(scoreStu1, scoreStu2, scoreStu3, scoreStu4, scoreStu5);
        Scanner sc = new Scanner(System.in);


        for (int i = 0; i < 4; i++) {
            System.out.println("enter score (student 1) for subject " + (i + 1));
            scoreStu1[i] = sc.nextDouble();
        }

        scoreStu.setScoreOne(scoreStu1);
        double aver1 = scoreStu.getAverScoreOne();
        System.out.println(aver1);
        scoreStu.getGrade(aver1);

        for (int i = 0; i < 4; i++) {
            System.out.println("enter score (student 2) for subject " + (i + 1));
            scoreStu2[i] = sc.nextDouble();
        }

        scoreStu.setScoreTwo(scoreStu2);
        double aver2 = scoreStu.getAverScoreTwo();
        System.out.println(aver2);
        scoreStu.getGrade(aver2);

        for (int i = 0; i < 4; i++) {
            System.out.println("enter score (student 3) for subject " + (i + 1));
            scoreStu3[i] = sc.nextDouble();
        }

        scoreStu.setScoreThree(scoreStu3);
        double aver3 = scoreStu.getAverScoreThree();
        System.out.println(aver3);
        scoreStu.getGrade(aver3);

        for (int i = 0; i < 4; i++) {
            System.out.println("enter score (student 4) for subject " + (i + 1));
            scoreStu4[i] = sc.nextDouble();
        }

        scoreStu.setScoreFour(scoreStu4);
        double aver4 = scoreStu.getAverScoreFour();
        System.out.println(aver4);
        scoreStu.getGrade(aver4);

        for (int i = 0; i < 4; i++) {
            System.out.println("enter score (student 5) for subject " + (i + 1));
            scoreStu5[i] = sc.nextDouble();
        }

        scoreStu.setScoreFive(scoreStu5);
        double aver5 = scoreStu.getAverScoreFive();
        System.out.println(aver5);
        scoreStu.getGrade(aver5);

        sc.nextLine();
        scoreStu.setAverageScoreList();
        double[] avgScore = scoreStu.getAverageScoreList();

        String[] nameArr = scoreStu.getName();
        String inputName;
        System.out.println("Enter name: ");
        inputName = sc.nextLine();
        int index = -1;
        for (int i = 0; i < 5; i++) {
            if (inputName.equalsIgnoreCase(nameArr[i])) {
                index = i;
            }
        }
        if (index == -1) {
            System.out.println("Cannot find the name of the student.");
        } else {
            System.out.println("The average score of student " + nameArr[index] + " is " + avgScore[index]);
        }
    }

}


