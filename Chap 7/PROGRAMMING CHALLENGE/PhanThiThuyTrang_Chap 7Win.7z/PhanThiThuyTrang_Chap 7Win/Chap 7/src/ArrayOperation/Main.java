package ArrayOperation;

import java.util.Scanner;
public class Main{
    public static void main(String[] args) {
        double [] number = new double[5];

        ArrayOperation array = new ArrayOperation(number);
        Scanner sc = new Scanner (System.in);
        for (int i = 0; i<5;i++){
            System.out.println("enter the number "+ (i+1) +" of array");
            number[i]=sc.nextDouble();
        }
        array.setNumber(number);
        array.getNumber();
        double total = array.getTotal(number);
        System.out.println("the total of number in array is "+total);
        double aver = array.getAverage(number);
        System.out.println("the average of sum is "+ aver);
        double min = array.getLowestNumber(number);
        System.out.println("the minimum number of this array is "+ min);
        double max = array.getHighestNumber(number);
        System.out.println("the maximum number of this array is "+ max);






    }

}