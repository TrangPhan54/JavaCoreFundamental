package ArrayOperation;


public class ArrayOperation {
    private double[] number ;
    public ArrayOperation(double[] number) {
        this.number = number;
    }

    public double[] getNumber() {
        return number;
    }

    public void setNumber(double[] number) {
        this.number = number;
    }


    public double getTotal(double [] numberOne) {
        double sum = 0;
        for (int i = 0; i < number.length; i++) {
            sum += numberOne[i];
        }
        return sum;
    }

    public double getAverage(double [] numberTwo) {
        double sum = getTotal(numberTwo);
        double average = sum / number.length;
        return average;
    }

    public double getLowestNumber(double[] numberTwo) {
        double lowest = number[0];
        int index = 0;
        for (int i = 1; i < number.length; i++) {
            if (number[i] < lowest) {
                index = i;
            }
        }
        return number[index];

    }

    public double getHighestNumber(double[] numberThree) {
        double highest = number[0];
        int index = 0;
        for (int i = 1; i < number.length; i++) {
            if (number[i] > highest) {
                index = i;
            }
        }
        return number[index];

    }
}