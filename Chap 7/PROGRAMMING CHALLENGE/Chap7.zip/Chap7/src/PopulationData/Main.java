package PopulationData;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) throws IOException {

        PrintWriter pw = new PrintWriter("USPopulation.txt", "UTF-8");
    }
}