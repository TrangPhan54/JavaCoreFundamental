package PhoneArrayList;
import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {
        ArrayList <PhoneBookArrayList> information  = new ArrayList <>();
        information.add(new PhoneBookArrayList("Anna","123456"));
        information.add(new PhoneBookArrayList("Bella","1467336"));
        information.add(new PhoneBookArrayList("Calvin","1289456"));
        information.add(new PhoneBookArrayList("Daniel","456386"));
        information.add(new PhoneBookArrayList("Ella","90229456"));
        System.out.println("\n PhoneBook Information");
        System.out.println();
        System.out.printf("%1s%15s\n","Name customer","phone number\n");
        for (PhoneBookArrayList phone: information){
            System.out.printf("%1s%15s\n",phone.getName(),phone.getPhoneNumber());


        }





    }
}
