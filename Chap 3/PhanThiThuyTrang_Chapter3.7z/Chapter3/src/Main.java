public class Main {
    public static void main(String[] args){
        char num = 'A';
        char num2 ='B';
        System.out.println (num2+0);
    }
}