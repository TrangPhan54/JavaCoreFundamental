package gradeactivity;

public class Main {
    public static void main(String[] args) {
        Essay1 essay = new Essay1(88,22,22,22,22);
        System.out.println(essay.getGrade());





        }
    }

